#fernando jara
#31/03/2025


nota =  70


if nota >= 40 :
    print ('Tu pasaste.')
else:
    print ('Tu repruebas.')    
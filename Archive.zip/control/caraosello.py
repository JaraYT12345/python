#jarajarita
#31/03/2025
#Fin de mes porfin

import random

num = random.randint(0, 1)

if num > 0.5 : 
    print ('cara')
else:
    print ('sello')    

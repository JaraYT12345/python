#fernando jara

elefantes = int(input('¿Cuantos elefantes quieres que se columpien?'))

for i in range (1, elefantes + 1):
    if i ==1:
        print (f"{i} elefante se balanceaba sobre la tela de una araña")

    else:
        print(f"{i} elefantes se balanceaba sobre la tela de una araña ")    
        print('como veia que resistia, fueron a llamar a otro elefante. \n')
#jaraaaaa

lluvia = [0.3, 0.0, 0.0, 1.2]

for i in range (len(lluvia)):
    print(lluvia[i])
#fernando jara

lluvia = [0.3, 0.0, 0.0, 1.2]

for i in lluvia:
    print(i)
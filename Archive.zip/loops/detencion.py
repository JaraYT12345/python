#fernando jara

frase = "No voy a josear en clase"

repeticiones = 100

for i in range (1, repeticiones + 1):
    print(f'{i}. {frase}')
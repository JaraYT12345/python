#metodo de las tuplas
#index (): encontrar la posicion de un elemento

tupla = ("a", "b", "c", "c")

print(tupla.index("b"))

#count(): cuenta cuantas veces aparece un elemento en la tupla

print(tupla.count("c"))
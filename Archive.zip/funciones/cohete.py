#fernando jara


def distancia_a_millas(distancia):
    return distancia / 1.609

respuesta = distancia_a_millas(10000)
# Se imprime la respuesta
print(f"La distancia es de {respuesta} millas")
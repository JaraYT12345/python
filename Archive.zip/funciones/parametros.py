#fernando jara

def feliz_cumpleaños (nombre):
    print('Feliz cumpleaños a ti')
    print('Feliz cumpleaños a ti')
    print('Feliz cumpleaños querido amigo' + nombre)
    print('Feliz cumpleaños a ti')

feliz_cumpleaños('Juan Diego')


#fernando jara


def decir_hola ():
    print('Hola')
    print('¿Como estas?')

decir_hola()
#fernando jara

#alcance
def sumar(x, y):
    respuesta = x + y
    return respuesta

print(sumar(5, 3))

#global

respuesta = 0

def sumar (x, y):
    respuesta = x + y
    return respuesta

print(sumar(5, 3))
#fernando jara
#21/04


def mi_funcion_suma(a, b):
    """
    Descripcion de la funcion a realizar
    """
    return a + b

mi_funcion_suma(5, 3)

print(mi_funcion_suma(5, 3))
print(mi_funcion_suma.__doc__)
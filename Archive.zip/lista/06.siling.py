#sirve para sacar los elementos entre 
#crear lista

mi_lista = [10, 30, 40, 50, 60, 70]

print(mi_lista[1:3])
print(mi_lista[2:])
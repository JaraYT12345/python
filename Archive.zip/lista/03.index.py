#list.index(valor)

#crear una lista 

mi_lista = [30, 10, 20, 40]

#obtener el valor del indice

indice = mi_lista.index(30)

print(indice) #la salida deberia de ser 0 
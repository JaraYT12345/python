#crear una lista

mi_lista = ["manzanas", "platanos", "cerezas", "tomates"]

print(mi_lista[0])
print(mi_lista[3])
print(mi_lista[1])
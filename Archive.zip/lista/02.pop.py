#lista.pop(indice)

#crear una lista con valores

mi_lista = [10, 20, 30, 40]

#eliminar el valor en la posicion



eliminados = mi_lista.pop(2)

print(mi_lista)
print(eliminados)
#print(eliminado)